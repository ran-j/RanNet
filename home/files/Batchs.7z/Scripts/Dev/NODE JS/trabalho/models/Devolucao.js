var mongoose = require('mongoose');

var DevolucaoDataSchema = new Schema({   
    data: {
		type: String,
		required: true,
	},
	nivelDeTanque: {
		type: String,
		required: true,
	},
	quilometragem: {
		type: String,
		required: true,
	},
	entregouNotas: {
		type: String,
		required: true,
	},
}, {collection: 'Devolucao'});  
   
var Registro = mongoose.model('DevolucaoData', DevolucaoDataSchema); 

module.exports = Registro;