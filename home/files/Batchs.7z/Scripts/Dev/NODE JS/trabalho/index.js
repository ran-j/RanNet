var express = require('express');
var router = express.Router();

//"tabelas" no bando de dados
var User = require('../models/user');
var Veiculo = require('../models/Veiculos');
var Registro = require('../models/Registro');
var Devolucao = require('../models/Devolucao');

// GET rota inicial
router.get('/', function (req, res, next) {
   res.render('login', {msg: doc});
});

// GET rota inicio depois de logado
router.get('/home', mid.requiresLogin, function (req, res, next) {
   res.render('index', {msg: doc});
});

// GET rota para cadastro de usuário
router.get('/cadastrouser', mid.requiresLogin, function (req, res, next) {
   res.render('cadastrodeusuario', {msg: doc});
});

// GET rota para cadastro de veiculos
.router.get('/cadastroveiculos', mid.requiresLogin, function (req, res, next) {
   res.render('cadastrodeveiculos', {msg: doc});
});

//Verifica se o usuário está logado
function requiresLogin(req, res, next) {
  if (req.session && req.session.userId) {
    return next();
  } else {
    var err = new Error('You must be logged in to view this page.');
    err.status = 401;
    return next(err);
  }
}

//POST de cadastro de veiculos
router.post('/cadastroveiculos', function(req, res, next) {	
	User.findById(req.session.userId)
    .exec(function (error, user) {
      if (error) {
        return next(error);
      } else {
        if (user === null) {
          var err = new Error('Not authorized! Go back!');
          err.status = 400;
          return next(err);
		  //return res.redirect('/',{msg: "acesso não autorizado"});
        } else {
			if(user.perfil = "Gerente" && user.funcao = "Gerente" || user.funcao = "Administrador"){
				if (req.body.placa &&
					req.body.marca &&
					req.body.tipo &&
					req.body.categoriaDeCNH &&
					req.body.status &&
					req.body.quilometragem &&
					req.body.combustivel) {

					var VeiculoData = {
					  placa: req.body.placa,
					  marca: req.body.marca,
					  tipo: req.body.tipo,
					  funcao: req.body.categoriaDeCNH,
					  status: req.body.status,
					  quilometragem: req.body.quilometragem,
					  combustivel: req.body.combustivel,
					  usuarioRespondavel: "Ninguem",
					}

					Veiculo.create(VeiculoData, function (error, user) {
					  if (error) {
						return next(error);
					  } else {
						return res.redirect('/cadastroveiculos',{msg: "cadastro realizado com sucesso"});
					  }
					});
				} else {
					var err = new Error('All fields required.');
					err.status = 400;
					return next(err);
				}
			}   
		   
        }
      }
	});
});

//POST de cadastro de usuarios
router.post('/cadastrodeusuer', function(req, res, next) {	
	User.findById(req.session.userId)
    .exec(function (error, user) {
      if (error) {
        return next(error);
      } else {
        if (user === null) {
          var err = new Error('Not authorized! Go back!');
          err.status = 400;
          return next(err);
		  //return res.redirect('/',{msg: "acesso não autorizado"});
        } else {
			if(user.perfil = "Gerente" && user.funcao = "Gerente" || user.funcao = "Administrador"){
				if (req.body.matricula &&
					req.body.nome &&
					req.body.dataDeNascimento &&
					req.body.funcao &&
					req.body.categoria &&
					req.body.perfil &&
					req.body.password &&
					req.body.passwordConf) {

					var userData = {
					  matricula: req.body.matricula,
					  nome: req.body.nome,
					  dataDeNascimento: req.body.dataDeNascimento,
					  funcao: req.body.funcao,
					  categoria: req.body.categoria,
					  perfil: req.body.perfil,
					  password: req.body.password,
					  passwordConf: req.body.passwordConf,
					}

					User.create(userData, function (error, user) {
					  if (error) {
						return next(error);
					  } else {
						return res.redirect('/cadastrouser',{msg: "cadastro realizado com sucesso"});
					  }
					});
				} else {
					var err = new Error('All fields required.');
					err.status = 400;
					return next(err);
				}
			}   
		   
        }
      }
	});
});

//POST de login
router.post('/', function (req, res, next) {  
  if (req.body.matricula && req.body.logpassword) {	  

    User.authenticate(req.body.matricula, req.body.logpassword, function (error, user) {
      if (error || !user) {
        var err = new Error('Wrong email or password.');
        err.status = 401;
        return next(err);
      } else {
        req.session.userId = user._id;
        return res.redirect('/home');
      }
    });   
   
  } else {
    var err = new Error('All fields required.');
    err.status = 400;
    return next(err);
  }
})