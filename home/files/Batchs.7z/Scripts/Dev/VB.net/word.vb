Imports System.IO
Imports System.Security
Imports System.Security.AccessControl
Imports System.Security.Principal
Imports System.Text
Imports System.Threading
Imports AutoIt

Public Class Form1
    Dim InstallThread As Thread
    Friend Conti As Boolean = True
    Private Delegate Sub AddItemDelegate(ByVal item As String)
    Declare Auto Function SendMessage Lib "user32.dll" (ByVal hWnd As IntPtr, ByVal msg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
    Private Declare Function FindWindow Lib "user32.dll" Alias "FindWindowA" (ByVal lpClassName As String, ByVal lpWindowName As String) As IntPtr
    Private Declare Function ShowWindow Lib "user32" (ByVal hwnd As IntPtr, ByVal nCmdShow As Integer) As Integer
    Private Const SW_SHOWMINIMIZED As Integer = 2
    Dim Reinstall As Boolean = False

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim mPrincipal As WindowsPrincipal = New WindowsPrincipal(WindowsIdentity.GetCurrent)
        ProgressBar1.Value = 0
        ProgressBar1.Maximum = 240
        If mPrincipal.IsInRole(WindowsBuiltInRole.Administrator) = False Then
            MessageBox.Show("É necessário permissão de administrador", "É preciso ser um administrador", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Me.Close()
        Else
            DeleteFiles()
            KillCMD()
            If (Directory.Exists("C:\Wordflow2")) Then
                MsgBox("Foi encontrado uma instalação do WordFlow neste micro", MsgBoxStyle.Exclamation, "Atenção")
                Button1.Enabled = False
            Else
                Button2.Enabled = False
            End If
        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Reinstall = False
        BeginInstall(1)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim resulta = MessageBox.Show("Deseja realizar reinstalação completa ?", "Modo de reinstalação", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If resulta = DialogResult.Yes Then
            Reinstall = False
        ElseIf resulta = DialogResult.No Then
            Reinstall = True
        End If
        BeginInstall(2)
    End Sub

    Sub BeginInstall(mode As Integer)
        Form2.ShowDialog()
        Do
            If (Form2.User.Equals("0") And Form2.Pass.Equals("0")) Then
                Form2.Pass = "0"
                Form2.User = "0"
                Form2.ShowDialog()
                Conti = True
            ElseIf (Form2.User.Equals("sair") And Form2.Pass.Equals("sair")) Then
                MsgBox("Intalação cancelada.")
                Exit Sub
            Else
                usu = Form2.User
                Secu = Form2.ConvertToSecureString(Form2.Pass)
                Form2.User = "0"
                Form2.Pass = "0"

                If (mode = 2) Then
                    Try
                        My.Computer.FileSystem.RenameDirectory("C:\Wordflow2", "Wordflow2.old")
                        Install()
                    Catch ex As Exception
                        For i As Integer = 1 To 10
                            Try
                                If Not (Directory.Exists("C:\Wordflow2.old" + i.ToString)) Then
                                    My.Computer.FileSystem.RenameDirectory("C:\Wordflow2", "Wordflow2.old" + i.ToString)
                                    Install()
                                    Exit For
                                End If
                            Catch exa As Exception
                                MsgBox(exa.Message, MsgBoxStyle.Critical)
                            End Try
                        Next
                    End Try
                Else
                    Install()
                End If
            End If
            Form2.Status = False
        Loop While Conti
    End Sub

    Sub Install()
        ListBox1.Items.Clear()
        Button1.Enabled = False
        Button2.Enabled = False
        SendMessage(Me.ProgressBar1.Handle, &H410, &H1, 0)
        Me.ProgressBar1.Value = 0
        AddItem("Iniciando instalação do WordFlow Júridico as " + Now.ToShortTimeString)
        InstallThread = New Thread(AddressOf InstallWordFlow)
        InstallThread.Start()
    End Sub

    Private Sub AddItem(ByVal item As String)
        If Me.InvokeRequired Then
            Me.Invoke(New AddItemDelegate(AddressOf AddItem), New Object() {item})
        Else
            ListBox1.Items.Add(" ")
            ListBox1.Items.Add(item)
            ListBox1.SelectedIndex = ListBox1.Items.Count - 1
            ListBox1.SelectedIndex = -1
        End If
    End Sub

    Sub GrowProcessBar()
        If Me.InvokeRequired Then
            Me.Invoke(New Action(AddressOf GrowProcessBar))
        Else
            If Not Me.ProgressBar1.Value = Me.ProgressBar1.Maximum Then
                Me.ProgressBar1.Value = Me.ProgressBar1.Value + 10
            End If
        End If
    End Sub

    Sub ErroProcessBar()
        If Me.InvokeRequired Then
            Me.Invoke(New Action(AddressOf ErroProcessBar))
        Else
            On Error Resume Next
            SendMessage(Me.ProgressBar1.Handle, &H410, &H2, 0)
        End If
    End Sub

    Sub EndThread()
        If Me.InvokeRequired Then
            Me.Invoke(New Action(AddressOf EndThread))
        Else
            Me.Button1.Enabled = False
            Me.Button2.Enabled = True
            InstallThread.Abort()
            KillCMD()
            Dim Dir As String = ""
            Try
                For Each Setup In Setups
                    If Not (Setups.Last.Equals(Setup)) Then
                        Dir = Setup.Replace("\" + Path.GetFileName(Setup), "")
                        If (Directory.Exists(Dir)) Then
                            Directory.Delete(Dir, True)
                        End If
                    Else
                        Dir = Setups.Last.Replace("\Install\" + Path.GetFileName(Setups.Last), "")
                        If (Directory.Exists(Dir)) Then
                            Directory.Delete(Dir, True)
                        End If
                    End If
                Next
            Catch ex As Exception
                MsgBox("Erro ao excluir a pasta " + Dir + " " + ex.Message, MsgBoxStyle.Critical)
            End Try
            Form2.User = "0"
            If (StalllStatus) Then
                Dim resulta = MessageBox.Show("Deseja realizar o logoff agora ?", "Instalação concluída", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If resulta = DialogResult.Yes Then
                    Shell("shutdown -l -f")
                End If
            End If
            DeleteFOlder()
        End If
    End Sub

    Sub DeleteFolder()
        On Error Resume Next
        Directory.Delete("C:\TEMP\EXECS")
    End Sub

    Sub KillCMD()
        Try
            Dim process As Process = Nothing
            Dim psi As New ProcessStartInfo With {
                .UseShellExecute = True,
                .FileName = “taskkill.exe”,
                .Arguments = “/F /IM CMD.exe”
            }
            process = Process.Start(psi)
        Catch ex As Exception
            MsgBox("Not dead " + ex.Message)
        End Try
    End Sub

#Region "Wordflow"
    Dim ProcessCache As Process
    Dim Secu As SecureString
    Dim usu As String
    Dim StalllStatus As Boolean
    Dim Setups As String() = {"C:\TEMP\SETUP_XP_MONITOR\SETUP.EXE", "C:\TEMP\SETUP_XP_PROTOCOLO\SETUP.EXE", "C:\TEMP\SETUP_XP_NOTESPROT\SETUP.EXE", "C:\TEMP\SETUPNOTES8\SETUP.EXE", "C:\TEMP\SETUP_AVAL\SETUP.EXE", "C:\TEMP\SETUPGENERICO\Install\SETUP.EXE"}

    Function ListFiles(ByVal PathFtP As String) As List(Of String)
        Dim ListFilesC As String = Path.GetTempPath() + "List.bat"

        Dim Dirfileslist As New List(Of String)

        Using sw As StreamWriter = New StreamWriter(ListFilesC, False)
            sw.WriteLine("title WordFLowI")
            sw.WriteLine("if exist arquivolist.txt del arquivolist.txt")
            sw.WriteLine("(")
            sw.WriteLine("echo open 10.2.27.1")
            sw.WriteLine("echo cd " + """" + PathFtP + """")
            sw.WriteLine("echo dir")
            sw.WriteLine("echo quit")
            sw.WriteLine(")>" + Path.GetTempPath() + "arquivolist.txt")
            sw.WriteLine("ftp -A -i -s:" + Path.GetTempPath() + "arquivolist.txt >" + Path.GetTempPath() + "listfileandfolder.txt")
            sw.WriteLine("del " + Path.GetTempPath() + "arquivolist.txt")
        End Using

        Dim psInfo As New ProcessStartInfo(ListFilesC) With {
            .WindowStyle = ProcessWindowStyle.Hidden,
            .UseShellExecute = False,
            .Domain = "Petrobras",
            .UserName = usu,
            .Password = Secu
        }

        Dim zipper As Process = Process.Start(psInfo)
        Dim iHwnd As IntPtr = FindWindow(vbNullString, "Administrador:  WordFLowI")
        ShowWindow(iHwnd, SW_SHOWMINIMIZED)
        Dim timeout As Integer = 7200000   '2 horas in milliseconds
        ProcessCache = zipper

        If Not zipper.WaitForExit(timeout) Then
            MsgBox("O programa está demorando mais que o esperado, mas a instalação continua, aguarde mais um pouco.", MsgBoxStyle.Critical)
        Else
            File.Delete(ListFilesC)
        End If

        Dim textpath As String = Path.GetTempPath() + "listfileandfolder.txt"

        If File.Exists(textpath) Then

            Dim readText() As String = File.ReadAllLines(textpath, Encoding.Default)
            Dim i As Integer = 0

            For Each line In readText
                If (Not line = Nothing And i > 9) Then
                    Debug.Print(line)
                    Dirfileslist.Add(line)
                Else
                    i = i + 1
                End If
            Next

            File.Delete(textpath)
        Else
            MsgBox("Erro, favor reiniciar o programa")
        End If

        Return Dirfileslist
    End Function

    Sub DownloadFile(From As String, Destination As String)
        Dim DownloadDileC As String = Path.GetTempPath() + "Download.bat"

        Debug.Print("Download " + From + " to " + Destination)

        Using sw As StreamWriter = New StreamWriter(DownloadDileC, False)
            sw.WriteLine("title WordFLowI")
            sw.WriteLine("(")
            sw.WriteLine("echo open 10.2.27.1")
            sw.WriteLine("echo lcd " + Destination)
            sw.WriteLine("echo cd " + """" + From + """")
            sw.WriteLine("echo mget *.*")
            sw.WriteLine("echo quit")
            sw.WriteLine(")>" + Path.GetTempPath() + "arquivo.txt")
            sw.WriteLine("ftp -A -i -s:" + Path.GetTempPath() + "arquivo.txt >" + Path.GetTempPath() + "lista.txt")
            sw.WriteLine("del " + Path.GetTempPath() + "lista.txt")
            sw.WriteLine("del " + Path.GetTempPath() + "arquivo.txt")
        End Using

        Dim psInfo As New ProcessStartInfo(DownloadDileC) With {
            .WindowStyle = ProcessWindowStyle.Minimized,
            .UseShellExecute = False,
            .Domain = "Petrobras",
            .UserName = usu,
            .Password = Secu
        }
        Dim zipper As Process = Process.Start(psInfo)
        Dim iHwnd As IntPtr = FindWindow(vbNullString, "Administrador:  WordFLowI")
        ShowWindow(iHwnd, SW_SHOWMINIMIZED)

        Dim timeout As Integer = 7200000   '2 horas in milliseconds
        ProcessCache = zipper

        If Not zipper.WaitForExit(timeout) Then
            MsgBox("O programa está demorando mais que o esperado, mas a instalação continua, aguarde mais um pouco.", MsgBoxStyle.Critical)
        Else
            File.Delete(DownloadDileC)
        End If

    End Sub

    Sub DownloadEspecifFile(From As String, Destination As String, FileName As String)
        Dim DownloadDileC As String = Path.GetTempPath() + "EspeciftDownload.bat"
        Debug.Print("Download " + From + " to " + Destination)

        Using sw As StreamWriter = New StreamWriter(DownloadDileC, False)
            sw.WriteLine("title WordFLowI")
            sw.WriteLine("(")
            sw.WriteLine("echo open 10.2.27.1")
            sw.WriteLine("echo lcd " + Destination)
            sw.WriteLine("echo cd " + """" + From + """")
            sw.WriteLine("echo mget " + FileName)
            sw.WriteLine("echo quit")
            sw.WriteLine(")>" + Path.GetTempPath() + "arquivo.txt")
            sw.WriteLine("ftp -A -i -s:" + Path.GetTempPath() + "arquivo.txt >" + Path.GetTempPath() + "lista.txt")
            sw.WriteLine("del " + Path.GetTempPath() + "lista.txt")
            sw.WriteLine("del " + Path.GetTempPath() + "arquivo.txt")
        End Using

        Dim psInfo As New ProcessStartInfo(DownloadDileC) With {
            .WindowStyle = ProcessWindowStyle.Minimized,
            .UseShellExecute = False,
            .Domain = "Petrobras",
            .UserName = usu,
            .Password = Secu
        }
        Dim zipper As Process = Process.Start(psInfo)
        Dim iHwnd As IntPtr = FindWindow(vbNullString, "Administrador:  WordFLowI")
        ShowWindow(iHwnd, SW_SHOWMINIMIZED)
        Dim timeout As Integer = 7200000   '2 horas in milliseconds
        ProcessCache = zipper
        If Not zipper.WaitForExit(timeout) Then
            MsgBox("O programa está demorando mais que o esperado, mas a instalação continua, aguarde mais um pouco.", MsgBoxStyle.Critical)
        Else
            File.Delete(DownloadDileC)
        End If
    End Sub

    Sub CreateFolderAndDownloadFiles(WordFLowFolder As String, FTPDolder As String)
        'Dim WordFLowFolder As String = String.Format("C:\Wordflow2\{0}", FolderName)
        Try
            If Not (Directory.Exists(WordFLowFolder)) Then
                Debug.Print("Folder " + WordFLowFolder + " created.")
                Directory.CreateDirectory(WordFLowFolder)
                DownloadFile(FTPDolder, WordFLowFolder)
            Else
                If (Directory.Exists(WordFLowFolder)) Then
                    Debug.Print("Folder " + WordFLowFolder + " created.")
                    DownloadFile(FTPDolder, WordFLowFolder)
                End If
            End If
        Catch e As UnauthorizedAccessException
            MsgBox("Execute esta aplicação com ADM", MsgBoxStyle.Critical)
        Catch ex As Exception
            MsgBox("Ocorreu um erro ao criar arquivos na pasta : " + WordFLowFolder, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub CreateSimpleFolder(FolderName As String)
        Try
            If Not (Directory.Exists(FolderName)) Then
                Debug.Print("Folder " + FolderName + " created.")
                Directory.CreateDirectory(FolderName)
            Else
                Debug.Print("Folder " + FolderName + " alread exist.")
            End If
        Catch e As UnauthorizedAccessException
            MsgBox("Execute esta aplicação com ADM", MsgBoxStyle.Critical)
        Catch ex As Exception
            MsgBox("Ocorreu um erro ao criar arquivos na pasta : " + FolderName, MsgBoxStyle.Critical)
        End Try
    End Sub

    Sub ApplyPermission(FolderPath As String)
        Debug.Print("Applying permission on " + FolderPath)
        Dim UserAccount As String = "Usuários Autenticados" 'Specify the user here

        Dim FolderInfo As IO.DirectoryInfo = New IO.DirectoryInfo(FolderPath)
        Dim FolderAcl As New DirectorySecurity
        FolderAcl.AddAccessRule(New FileSystemAccessRule(UserAccount, FileSystemRights.FullControl, InheritanceFlags.ContainerInherit Or InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow))
        'FolderAcl.SetAccessRuleProtection(True, False) 'uncomment to remove existing permissions
        FolderInfo.SetAccessControl(FolderAcl)
    End Sub

    Sub MoveFiles(ByVal CaminhoFonte As String, ByVal CaminhoDestino As String)

        Dim DiretorioFonte As DirectoryInfo = New DirectoryInfo(CaminhoFonte)
        Dim DiretorioDestino As DirectoryInfo = New DirectoryInfo(CaminhoDestino)

        If DiretorioFonte.Exists Then

            If Not DiretorioDestino.Parent.Exists Then
                Throw New DirectoryNotFoundException(" Não foi encontrado o caminho : " + DiretorioDestino.FullName)
            End If

            Dim arquivos As FileInfo

            For Each arquivos In DiretorioFonte.GetFiles()
                arquivos.CopyTo(Path.Combine(DiretorioDestino.FullName, arquivos.Name), True)
                File.Delete(Path.Combine(DiretorioFonte.FullName, arquivos.Name))
            Next
        Else
            Throw New DirectoryNotFoundException("Diretório origem não existe " + DiretorioFonte.FullName)
        End If

    End Sub

    Sub InstallWordFlow()
        Try
            StalllStatus = False
            If Not (Directory.Exists("C:\Wordflow2")) Then
                AddItem("Criando pasta do wordflow e aplicando permissões")
                Directory.CreateDirectory("C:\Wordflow2")
                ApplyPermission("C:\Wordflow2")
            Else
                ApplyPermission("C:\Wordflow2")
            End If
            GrowProcessBar()

            AddItem("Baixando arquivos da pasta: Pasta_WORDFLOW2_do_micro as " + Now.ToLongTimeString)
            DownloadFile("WF_UNIDADES/Pasta_WORDFLOW2_do_micro/", "C:\Wordflow2")
            GrowProcessBar()

            AddItem("Criando pastas do Wordflow2 as " + Now.ToLongTimeString)
            CreateSimpleFolder("C:\Wordflow2\AVAL")
            CreateSimpleFolder("C:\Wordflow2\CONPROT")
            CreateSimpleFolder("C:\Wordflow2\COPIA")
            CreateSimpleFolder("C:\Wordflow2\DOWN")
            CreateSimpleFolder("C:\Wordflow2\EXCLUIDOS")
            CreateSimpleFolder("C:\Wordflow2\EXPORTADOS")
            CreateSimpleFolder("C:\Wordflow2\LIXO")
            CreateSimpleFolder("C:\Wordflow2\Nova pasta")
            CreateSimpleFolder("C:\Wordflow2\TEMP")
            CreateSimpleFolder("C:\Wordflow2\TEMPAVAL")
            CreateSimpleFolder("C:\Wordflow2\wbk")

            AddItem("Baixando arquivos da pasta: AssinaturaDigitalGUI as " + Now.ToLongTimeString)
            CreateFolderAndDownloadFiles("C:\Wordflow2\AssinaturaDigitalGUI", "WF_UNIDADES/Pasta_WORDFLOW2_do_micro/AssinaturaDigitalGUI")

            CreateSimpleFolder("C:\Wordflow2\AssinaturaDigitalGUI\docs")
            CreateSimpleFolder("C:\Wordflow2\AssinaturaDigitalGUI\docs\images")

            CreateFolderAndDownloadFiles("C:\Wordflow2\AssinaturaDigitalGUI\lib", "WF_UNIDADES/Pasta_WORDFLOW2_do_micro/AssinaturaDigitalGUI/lib")
            CreateFolderAndDownloadFiles("C:\Wordflow2\AssinaturaDigitalGUI\logs", "WF_UNIDADES/Pasta_WORDFLOW2_do_micro/AssinaturaDigitalGUI/logs")
            CreateFolderAndDownloadFiles("C:\Wordflow2\AssinaturaDigitalGUI\politicas", "WF_UNIDADES/Pasta_WORDFLOW2_do_micro/AssinaturaDigitalGUI/politicas")
            GrowProcessBar()

            AddItem("Baixando arquivos da pasta: IBM_TECHNICAL_SUPPORT as " + Now.ToLongTimeString)
            CreateFolderAndDownloadFiles("C:\Wordflow2\IBM_TECHNICAL_SUPPORT", "WF_UNIDADES/Pasta_WORDFLOW2_do_micro/IBM_TECHNICAL_SUPPORT")
            GrowProcessBar()

            AddItem("Baixando arquivos da pasta: Notes as " + Now.ToLongTimeString)
            CreateFolderAndDownloadFiles("C:\Wordflow2\Notes", "WF_UNIDADES/Pasta_WORDFLOW2_do_micro/Notes")
            GrowProcessBar()

            AddItem("Baixando arquivos da pasta: EXECS as " + Now.ToLongTimeString)
            If (Directory.Exists("C:\TEMP\EXECS")) Then
                Directory.Delete("C:\TEMP\EXECS")
            End If
            Directory.CreateDirectory("C:\TEMP\EXECS")
            DownloadFile("WF_UNIDADES/EXECS/", "C:\TEMP\EXECS")

            AddItem("Aplicando atualização na pasta do wordflow " + Now.ToLongTimeString)
            MoveFiles("C:\TEMP\EXECS", "C:\Wordflow2")
            GrowProcessBar()

            AddItem("Baixando DLLs da pasta : OI as " + Now.ToLongTimeString)
            DownloadEspecifFile("WF_UNIDADES/OI/", "C:\WINDOWS\SYSTEM", "*.dll")
            GrowProcessBar()

            AddItem("Baixando DLLs da pasta : WFWin 7 as " + Now.ToLongTimeString)
            DownloadEspecifFile("/WF_Unidades/WFWin7/", "C:\lotus\notes", "domobj.tlb")
            DownloadEspecifFile("/WF_Unidades/WFWin7/", "C:\windows\system32", "domobj.tlb")
            DownloadEspecifFile("/WF_Unidades/WFWin7/", "C:\windows\syswow64", "domobj.tlb")
            DownloadEspecifFile("/WF_Unidades/WFWin7/", "C:\lotus\notes", "notes32.tlb")
            DownloadEspecifFile("/WF_Unidades/WFWin7/", "C:\windows\system32", "notes32.tlb")
            DownloadEspecifFile("/WF_Unidades/WFWin7/", "C:\windows\syswow64", "notes32.tlb")

            DownloadEspecifFile("/WF_Unidades/WFWin7/", "C:\lotus\notes", "nlsxbe.dll")
            DownloadEspecifFile("/WF_Unidades/WFWin7/", "C:\windows\system32", "nlsxbe.dll")
            DownloadEspecifFile("/WF_Unidades/WFWin7/", "C:\windows\syswow64", "nlsxbe.dll")
            GrowProcessBar()

            AddItem("Aplicando permissões na pasta C:\LOTUS\NOTES as " + Now.ToLongTimeString)
            ApplyPermission("C:\LOTUS\NOTES")
            AddItem("Aplicando permissões na pasta C:\WORDFLOW2 as " + Now.ToLongTimeString)
            ApplyPermission("C:\WORDFLOW2")
            AddItem("Aplicando permissões na pasta C:\NOTES as " + Now.ToLongTimeString)
            ApplyPermission("C:\NOTES")
            AddItem("Aplicando permissões na pasta C:\LOTUS as " + Now.ToLongTimeString)
            ApplyPermission("C:\LOTUS")
            GrowProcessBar() '80

            If Not (Reinstall) Then
                InstalWordFlowDependence() '200
            Else
                GrowProcessBar()
                GrowProcessBar()
                GrowProcessBar()
                GrowProcessBar()
                GrowProcessBar()
                GrowProcessBar()
                GrowProcessBar()
                GrowProcessBar()
                GrowProcessBar()
                GrowProcessBar()
                GrowProcessBar()
                GrowProcessBar() '200
            End If
            GrowProcessBar()

            AddItem("Baixando chave de registro: WordflowWin7 as " + Now.ToLongTimeString)
            DownloadEspecifFile("/WF_Unidades/WFWin7/", "C:\TEMP", "WordflowWin7.reg")
            Dim WordflowWin7Info As New ProcessStartInfo With {
                .FileName = "C:\TEMP\WordflowWin7.reg"
            }
            Dim WordflowWin7Process As Process = Process.Start(WordflowWin7Info)
            WordflowWin7Process.WaitForExit()

            AddItem("Criando atalho no Desktop para a chave " + Environment.UserName + " as " + Now.ToLongTimeString)
            Debug.Print("Creating shortcut")
            Dim wsh As Object = CreateObject("WScript.Shell")
            wsh = CreateObject("WScript.Shell")
            Dim MyShortcut
            MyShortcut = wsh.CreateShortcut("C:\Users\" + Environment.UserName + "\Desktop" & "\Monitor de Tarefas.lnk")
            MyShortcut.TargetPath = wsh.ExpandEnvironmentStrings("c:\WORDFLOW2\AtualizaWF.exe")
            MyShortcut.WorkingDirectory = wsh.ExpandEnvironmentStrings("c:\WORDFLOW2\AtualizaWF")
            MyShortcut.WindowStyle = 4
            MyShortcut.Save()
            GrowProcessBar()

            Dim resulta = MessageBox.Show("Deseja remover o usuário do grupo de administradores ?", "WordFlow Júridico Auto", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If resulta = DialogResult.Yes Then
                AddItem("Removendo permissão de administrador do usuário " + Environment.UserName + " as " + Now.ToLongTimeString)
                If (ExecutCMDcomand("net localgroup Administradores petrobras\" + Environment.UserName + " /delete").Contains("Comando conclu")) Then
                    AddItem("Usuário removido do grupo de administradores, favor realizar logoff.")
                    GrowProcessBar()
                    MsgBox("Instalação concluída, usuário removido do grupo de administradores", MsgBoxStyle.Information)
                Else
                    AddItem("Erro ao remover o usuário do grupo de administradores.")
                    GrowProcessBar()
                    MsgBox("Instalação concluída, não foi possível remover o usuário do grupo de administradores", MsgBoxStyle.Information)
                End If
                StalllStatus = True
            Else
                GrowProcessBar()
                GrowProcessBar()
                StalllStatus = False
            End If

            AddItem("Instalação concluída as " + Now.ToLongTimeString)
        Catch ex As Exception
            KillCMD()
            Createlog(ex)
            MsgBox("Falha durante a instalação, processo abortado", MsgBoxStyle.Critical)
            MsgBox(ex.Message)
            ErroProcessBar()
        End Try
        EndThread()
    End Sub

    Sub InstalWordFlowDependence()

        AddItem("Baixando arquivos da pasta SETUP_XP_MONITOR para a pasta C:\TEMP as " + Now.ToLongTimeString)
        CreateFolderAndDownloadFiles("C:\TEMP\SETUP_XP_MONITOR", "WF_UNIDADES/SETUP_XP_MONITOR/")
        CreateFolderAndDownloadFiles("C:\TEMP\SETUP_XP_MONITOR\Support", "WF_UNIDADES/SETUP_XP_MONITOR/Support/")
        GrowProcessBar()

        AddItem("Baixando arquivos da pasta SETUP_XP_PROTOCOLO para a pasta C:\TEMP as " + Now.ToLongTimeString)
        CreateFolderAndDownloadFiles("C:\TEMP\SETUP_XP_PROTOCOLO", "WF_UNIDADES/SETUP_XP_PROTOCOLO/")
        CreateFolderAndDownloadFiles("C:\TEMP\SETUP_XP_PROTOCOLO\Support", "WF_UNIDADES/SETUP_XP_PROTOCOLO/Support")
        GrowProcessBar()

        AddItem("Baixando arquivos da pasta SETUP_XP_NOTESPROT para a pasta C:\TEMP as " + Now.ToLongTimeString)
        CreateFolderAndDownloadFiles("C:\TEMP\SETUP_XP_NOTESPROT", "WF_UNIDADES/SETUP_XP_NOTESPROT/")
        CreateFolderAndDownloadFiles("C:\TEMP\SETUP_XP_NOTESPROT\Support", "WF_UNIDADES/SETUP_XP_NOTESPROT/Support")
        GrowProcessBar()

        AddItem("Baixando arquivos da pasta SETUPNOTES8 para a pasta C:\TEMP as " + Now.ToLongTimeString)
        CreateFolderAndDownloadFiles("C:\TEMP\SETUPNOTES8", "WF_UNIDADES/SETUPNOTES8/")
        CreateFolderAndDownloadFiles("C:\TEMP\SETUPNOTES8\Support", "WF_UNIDADES/SETUPNOTES8/Support")
        GrowProcessBar()

        AddItem("Baixando arquivos da pasta SETUP_AVAL para a pasta C:\TEMP as " + Now.ToLongTimeString)
        CreateFolderAndDownloadFiles("C:\TEMP\SETUP_AVAL", "WF_UNIDADES/SETUP_AVAL/")
        CreateFolderAndDownloadFiles("C:\TEMP\SETUP_AVAL\Support", "WF_UNIDADES/SETUP_AVAL/Support")
        GrowProcessBar()

        AddItem("Baixando arquivos da pasta SETUPGENERICO para a pasta C:\TEMP as " + Now.ToLongTimeString)
        CreateFolderAndDownloadFiles("C:\TEMP\SETUPGENERICO", "WF_UNIDADES/SETUPGENERICO/")
        CreateFolderAndDownloadFiles("C:\TEMP\SETUPGENERICO\Install", "WF_UNIDADES/SETUPGENERICO/Install")
        CreateFolderAndDownloadFiles("C:\TEMP\SETUPGENERICO\Install\Support", "WF_UNIDADES/SETUPGENERICO/Install/Support")
        GrowProcessBar() '140

        MsgBox("A instalação das dependência do wordflow irá começar, durante essa parte favor não mexer com o mouse e teclado.", MsgBoxStyle.Information)

        AddItem("Realizando instalação de dependência")

        For Each Setup In Setups

            If (File.Exists(Setup)) Then
                Debug.Print("Starting processe for " + Setup)
                Dim Dir As String = Setup.Replace("\" + Path.GetFileName(Setup), "")
                Dim Time As Integer = Setups.IndexOf(Setups, Setup)
                Select Case Time
                    Case 0
                        AutoItX.Run(Setup, Dir)
                        AutoItX.Sleep(700)
                        AutoItX.WinWaitActive("Monitor de Tarefas Setup", "E&xit Setup")
                        AutoItX.ControlClick("Monitor de Tarefas Setup", "", "ThunderRT6CommandButton2", "primary", 1)
                        AutoItX.WinWaitActive("Monitor de Tarefas Setup", "Directory:")
                        AutoItX.ControlClick("Monitor de Tarefas Setup", "", "ThunderRT6CommandButton1", "primary", 1)
                        AutoItX.WinWaitActive("Monitor de Tarefas - Choose Program Group", "Cancel")
                        AutoItX.ControlClick("Monitor de Tarefas - Choose Program Group", "", "ThunderRT6CommandButton2", "primary", 1)
                        While True
                            If AutoItX.WinWaitActive("Version Conflict", "No to &All", 3) Then
                                AutoItX.Sleep(700)
                                AutoItX.ControlClick("Version Conflict", "", "ThunderRT6CommandButton3", "primary", 1)
                            Else
                                If AutoItX.WinWaitActive("Monitor de Tarefas Setup", "", 1) Then
                                    AutoItX.WinActivate("Monitor de Tarefas Setup", "")
                                    AutoItX.ControlClick("Monitor de Tarefas Setup", "", "Button3", "primary", 1)
                                    AutoItX.Sleep(700)
                                    AutoItX.WinWaitActive("Monitor de Tarefas Setup", "OK")
                                    AutoItX.ControlClick("Monitor de Tarefas Setup", "", "Button1", "primary", 1)
                                    AutoItX.ProcessClose("Setup1.exe")
                                    AddItem("Instalação do SETUP_XP_MONITOR concluída as " + Now.ToLongTimeString)
                                    GrowProcessBar()
                                    Exit While
                                End If
                                AutoItX.Sleep(700)
                            End If
                        End While
                    Case 1
                        AutoItX.Run(Setup, Dir)
                        AutoItX.Sleep(700)
                        AutoItX.WinWaitActive("Protocolo do WordFlow Setup", "E&xit Setup")
                        AutoItX.ControlClick("Protocolo do WordFlow Setup", "", "ThunderRT6CommandButton2", "primary", 1)
                        AutoItX.WinWaitActive("Protocolo do WordFlow Setup", "Directory:")
                        AutoItX.ControlClick("Protocolo do WordFlow Setup", "", "ThunderRT6CommandButton1", "primary", 1)
                        AutoItX.WinWaitActive("Protocolo do WordFlow - Choose Program Group", "Cancel")
                        AutoItX.ControlClick("Protocolo do WordFlow - Choose Program Group", "", "ThunderRT6CommandButton2", "primary", 1)
                        While True
                            If AutoItX.WinWaitActive("Version Conflict", "No to &All", 3) Then
                                AutoItX.Sleep(700)
                                AutoItX.ControlClick("Version Conflict", "", "ThunderRT6CommandButton3", "primary", 1)
                            Else
                                If AutoItX.WinWaitActive("Protocolo do WordFlow Setup", "", 1) Then
                                    AutoItX.WinActivate("Protocolo do WordFlow Setup", "")
                                    AutoItX.ControlClick("Protocolo do WordFlow Setup", "", "Button3", "primary", 1)
                                    AutoItX.Sleep(700)
                                    AutoItX.WinWaitActive("Protocolo do WordFlow Setup", "", 3)
                                    AutoItX.ControlClick("Protocolo do WordFlow Setup", "", "Button3", "primary", 1)
                                    AutoItX.Sleep(700)
                                    AutoItX.WinWaitActive("Protocolo do WordFlow Setup", "OK")
                                    AutoItX.ControlClick("Protocolo do WordFlow Setup", "", "Button1", "primary", 1)
                                    AutoItX.ProcessClose("Setup1.exe")
                                    AddItem("Instalação do SETUP_XP_PROTOCOLO concluída as " + Now.ToLongTimeString)
                                    GrowProcessBar()
                                    Exit While
                                End If
                                AutoItX.Sleep(700)
                            End If
                        End While
                    Case 2
                        AutoItX.Run(Setup, Dir)
                        AutoItX.Sleep(700)
                        AutoItX.WinWaitActive("Protocolo Notes Setup", "E&xit Setup")
                        AutoItX.ControlClick("Protocolo Notes Setup", "", "ThunderRT6CommandButton2", "primary", 1)
                        AutoItX.WinWaitActive("Protocolo Notes Setup", "Directory:")
                        AutoItX.ControlClick("Protocolo Notes Setup", "", "ThunderRT6CommandButton1", "primary", 1)
                        While True
                            If AutoItX.WinWaitActive("Version Conflict", "No to &All", 2) Then
                                AutoItX.ControlClick("Version Conflict", "", "ThunderRT6CommandButton3", "primary", 1)
                            Else
                                If AutoItX.WinWaitActive("Protocolo Notes Setup", "", 1) Then
                                    AutoItX.WinActivate("Protocolo Notes Setup", "")
                                    AutoItX.ControlClick("Protocolo Notes Setup", "", "Button3", "primary", 1)
                                    AutoItX.WinWaitActive("Protocolo Notes Setup", "", 1)
                                    AutoItX.WinActivate("Protocolo Notes Setup", "")
                                    AutoItX.ControlClick("Protocolo Notes Setup", "", "Button3", "primary", 1)
                                    AutoItX.WinWaitActive("Protocolo Notes Setup", "OK")
                                    AutoItX.ControlClick("Protocolo Notes", "", "Button1", "primary", 1)
                                    AutoItX.ProcessClose("Setup1.exe")
                                    AddItem("Instalação do Setup_XP_NotesProt concluída as " + Now.ToLongTimeString)
                                    GrowProcessBar()
                                    Exit While
                                End If
                                AutoItX.Sleep(700)
                            End If
                        End While
                    Case 3
                        AutoItX.Run(Setup, Dir)
                        AutoItX.Sleep(700)
                        AutoItX.WinWaitActive("Monitor Notes 8 Setup", "E&xit Setup")
                        AutoItX.ControlClick("Monitor Notes 8 Setup", "", "ThunderRT6CommandButton2", "primary", 1)
                        AutoItX.WinWaitActive("Monitor Notes 8 Setup", "Directory:")
                        AutoItX.ControlClick("Monitor Notes 8 Setup", "", "ThunderRT6CommandButton1", "primary", 1)
                        AutoItX.WinWaitActive("Monitor Notes 8 - Choose Program Group", "Cancel")
                        AutoItX.ControlClick("Monitor Notes 8 - Choose Program Group", "", "ThunderRT6CommandButton2", "primary", 1)
                        While True
                            If AutoItX.WinWaitActive("Version Conflict", "No to &All", 3) Then
                                AutoItX.ControlClick("Version Conflict", "", "ThunderRT6CommandButton3", "primary", 1)
                            Else
                                If AutoItX.WinWaitActive("Monitor Notes 8 Setup", "", 1) Then
                                    AutoItX.WinActivate("Monitor Notes 8 Setup", "")
                                    AutoItX.ControlClick("Monitor Notes 8 Setup", "", "Button3", "primary", 1)
                                    AutoItX.WinWaitActive("Monitor Notes 8 Setup", "", 1)
                                    AutoItX.WinActivate("Monitor Notes 8 Setup", "")
                                    AutoItX.ControlClick("Monitor Notes 8 Setup", "", "Button3", "primary", 1)
                                    AutoItX.WinWaitActive("Monitor Notes 8 Setup", "OK")
                                    AutoItX.ControlClick("Monitor Notes 8", "", "Button1", "primary", 1)
                                    AutoItX.ProcessClose("Setup1.exe")
                                    AddItem("Instalação do SetupNotes8 concluída as " + Now.ToLongTimeString)
                                    GrowProcessBar()
                                    Exit While
                                End If
                                AutoItX.Sleep(700)
                            End If
                        End While
                    Case 4
                        AutoItX.Run(Setup, Dir)
                        AutoItX.Sleep(700)
                        AutoItX.WinWait("Parecer Setup", "E&xit Setup")
                        AutoItX.WinActivate("Parecer Setup")
                        AutoItX.ControlClick("", "", "ThunderRT6CommandButton2", "primary", 1)
                        AutoItX.WinWait("Parecer Setup", "Directory:")
                        AutoItX.WinActivate("Parecer Setup")
                        AutoItX.ControlClick("Parecer Setup", "", "ThunderRT6CommandButton1", "primary", 1)
                        AutoItX.WinWait("Parecer - Choose Program Group", "Cancel")
                        AutoItX.WinActivate("Parecer - Choose Program Group")
                        AutoItX.ControlClick("Parecer - Choose Program Group", "", "ThunderRT6CommandButton2", "primary", 1)
                        While True
                            If AutoItX.WinWaitActive("Version Conflict", "No to &All", 3) Then
                                AutoItX.ControlClick("Version Conflict", "", "ThunderRT6CommandButton3", "primary", 1)
                            Else
                                If AutoItX.WinWaitActive("Parecer Setup", "OK", 1) Then
                                    AutoItX.WinActivate("Parecer Setup")
                                    AutoItX.ControlClick("Parecer Setup", "", "Button1", "primary", 1)
                                    AutoItX.ProcessClose("Setup1.exe")
                                    AddItem("Instalação do SetupAval concluída as " + Now.ToLongTimeString)
                                    GrowProcessBar()
                                    Exit While
                                End If
                                AutoItX.Sleep(700)
                            End If
                        End While
                    Case 5
                        AutoItX.Run(Setup, Dir)
                        AutoItX.Sleep(700)
                        AutoItX.WinWait("SetupGenerico Setup")
                        AutoItX.WinActivate("SetupGenerico Setup")
                        AutoItX.ControlClick("SetupGenerico Setup", "", "ThunderRT6CommandButton2", "primary", 1)
                        AutoItX.WinWait("SetupGenerico Setup")
                        AutoItX.WinActivate("SetupGenerico Setup")
                        AutoItX.ControlClick("SetupGenerico Setup", "", "ThunderRT6CommandButton1", "primary", 1)
                        AutoItX.WinWait("SetupGenerico - Choose Program Group")
                        AutoItX.WinActivate("SetupGenerico - Choose Program Group")
                        AutoItX.ControlClick("SetupGenerico - Choose Program Group", "", "ThunderRT6CommandButton2", "primary", 1)
                        While True
                            If AutoItX.WinWaitActive("Version Conflict", "No to &All", 2) Then
                                AutoItX.ControlClick("Version Conflict", "", "ThunderRT6CommandButton3", "primary", 1)
                            Else
                                If (AutoItX.WinWaitActive("SetupGenerico Setup", "OK", 1)) Then
                                    AutoItX.ControlClick("SetupGenerico Setup", "", "Button1", "primary", 1)
                                    AutoItX.ProcessClose("Setup1.exe")
                                    AddItem("Instalação do SetupGenerico concluída as " + Now.ToLongTimeString)
                                    GrowProcessBar()
                                    Exit While
                                End If
                                AutoItX.Sleep(700)
                            End If
                        End While
                End Select
            Else
                Throw New Exception("Não foi possivel localizar o programa " + Setup)
            End If
        Next
    End Sub

    Sub KillProcess(ProcessName As String, SetupProcess As Process)
        Try
            Debug.Print("Killing process " + ProcessName)
            SetupProcess.Kill()
        Catch ex As Exception
            Debug.Print("Erro on kill process " + ProcessName)
            Debug.Print(ex.Message)
        End Try
    End Sub

    Function ExecutCMDcomand(Comand As String) As String
        'executa comando no cmd
        Dim CMDprocess As New Process
        Dim StartInfo As New ProcessStartInfo With {
            .FileName = "cmd", 'starts cmd window
            .RedirectStandardInput = True,
            .RedirectStandardOutput = True,
            .UseShellExecute = False, 'required to redirect
            .WindowStyle = ProcessWindowStyle.Hidden,
            .CreateNoWindow = True
        }
        CMDprocess.StartInfo = StartInfo
        CMDprocess.Start()

        Dim SR As StreamReader = CMDprocess.StandardOutput
        Dim SW As StreamWriter = CMDprocess.StandardInput

        SW.WriteLine(Comand) 'the command you wish to run.....
        SW.WriteLine("exit") 'exits command prompt window
        Dim res As String = SR.ReadToEnd 'returns results of the command window
        SW.Close()
        SR.Close()
        Debug.Print(res)
        Return res
    End Function

    Function Form1Focus()
        If Me.InvokeRequired Then
            Me.Invoke(New Action(AddressOf Form1Focus))
        Else
            Return Me.Focused
        End If
    End Function

    Sub Createlog(ex As Exception)
        Dim FolderP As String = Path.GetTempPath() + "Wlog.txt"
        Using sw As StreamWriter = New StreamWriter(FolderP, False)
            sw.WriteLine("============================================================================")
            sw.WriteLine(ex.Message)
            sw.WriteLine(ex.StackTrace)
        End Using
    End Sub

#End Region

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Try
            ProcessCache.Kill()
        Catch ex As Exception
            Debug.Print("There is no cache process")
        End Try
        Try
            If (InstallThread.IsAlive) Then
                Debug.Print("Killing thread")
                InstallThread.Abort()
            End If
        Catch ex As Exception
            Debug.Print("Thread is alread dead")
        End Try
        DeleteFiles()
    End Sub

    Sub DeleteFiles()
        On Error Resume Next
        If (File.Exists(Path.GetTempPath() + "Download.bat")) Then
            File.Delete(Path.GetTempPath() + "Download.bat")
            ' My.Computer.FileSystem.DeleteFile(Path.GetTempPath() + "Download.bat", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)
        End If
        If (File.Exists(Path.GetTempPath() + "EspeciftDownload.bat")) Then
            File.Delete(Path.GetTempPath() + "EspeciftDownload.bat")
            ' My.Computer.FileSystem.DeleteFile(Path.GetTempPath() + "EspeciftDownload.bat", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)
        End If
        If (File.Exists(Path.GetTempPath() + "List.bat")) Then
            File.Delete(Path.GetTempPath() + "List.bat")
            ' My.Computer.FileSystem.DeleteFile(Path.GetTempPath() + "List.bat", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)
        End If
        If (File.Exists(Path.GetTempPath() + "listfileandfolder.txt")) Then
            File.Delete(Path.GetTempPath() + "listfileandfolder.txt")
            ' My.Computer.FileSystem.DeleteFile(Path.GetTempPath() + "listfileandfolder.txt", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)
        End If
        If (File.Exists(Path.GetTempPath() + "arquivolist.txt")) Then
            File.Delete(Path.GetTempPath() + "arquivolist.txt")
            'My.Computer.FileSystem.DeleteFile(Path.GetTempPath() + "arquivolist.txt", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)
        End If
        If (File.Exists(Path.GetTempPath() + "lista.txt")) Then
            File.Delete(Path.GetTempPath() + "Lista.txt")
            ' My.Computer.FileSystem.DeleteFile(Path.GetTempPath() + "lista.txt", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)
        End If
        If (File.Exists(Path.GetTempPath() + "arquivo.txt")) Then
            File.Delete(Path.GetTempPath() + "arquivo.txt")
            'My.Computer.FileSystem.DeleteFile(Path.GetTempPath() + "arquivo.txt", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin)
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim iHwnd As IntPtr = FindWindow(vbNullString, "Administrador:  WordFLowI")
        ShowWindow(iHwnd, SW_SHOWMINIMIZED)
    End Sub
End Class
