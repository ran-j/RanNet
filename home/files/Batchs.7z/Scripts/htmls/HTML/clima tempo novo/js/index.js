// v3.1.0
//Docs at http://simpleweatherjs.com
$(document).ready(function() {
  if (navigator.geolocation) { navigator.geolocation.getCurrentPosition(function(position) {
    var lart = position.coords.latitude;
    var longg= position.coords.longitude;
    procuracidade(lart,longg);
    
    }, function() {
       alert("erro dos brabos");
    });
  }else{
    alert("Esse navegador não aceita pegar posição");
    procuracidade(-21.7665004,-41.3454156);
  }
  

function procuracidade(latt,longg){
  $.ajax({ url:'http://maps.googleapis.com/maps/api/geocode/json?latlng='+latt+','+longg+'&sensor=true',
         success: function(data){
             var cidadev = (data.results[2].formatted_address);
             var cidaden = cidadev.replace("-", ",").replace(", Brasil", ""); 
             vai(cidaden); 
              
         }
});
}
  
function vai(local) {
  $.simpleWeather({
    location: local,
    woeid: '',
    unit: 'c',
    success: function(weather) {
      html = '<h2><i class="icon-'+weather.code+'"></i> '+weather.temp+'&deg;'+weather.units.temp+'</h2>';
      html += '<ul><li>'+weather.city+', '+weather.region+'</li>';
      html += '<li class="currently">'+weather.currently+'</li>';
      html += '<li>'+weather.wind.direction+' '+weather.wind.speed+' '+weather.units.speed+'</li></ul>';
  
      $("#weather").html(html);
    },
    error: function(error) {
      $("#weather").html('<p>'+error+'</p>');
    }
  });
}
});