var japopulado = 0;
var proximos = [];

function pontosproximos(arraydepontos){

  var anterior= 200000;
  var maximodepontos = 5;

 for (var i = 0; i < arraydepontos.length; i++) {

     if (japopulado == 0){
	
	if (maximodepontos <= 5){

           var distanciaentrepontos = distancia(arraydepontos.lat,arraydepontos.lng,atuallat,atuallng);

	   if (distanciaentrepontos<anterior){
               proximos.push(arraydepontos.lat+","+arraydepontos.lng+","+distanciaentrepontos);
	       maximodepontos +=1;
	   }

	}else{
	   break;
	}
     }else{
	var distanciaentrepontos2 = distancia(arraydepontos.lat,arraydepontos.lng,atuallat,atuallng);

	if (maximodepontos < 5){

	  for (var i = 0; i < proximos.length; i++) {

	      if (proximos < distanciaentrepontos2){
		 proximos(i).add(arraydepontos.lat+","+arraydepontos.lng+","+distanciaentrepontos2);
		 maximodepontos +=1;
	      }
	      
	  }

	}else{
 	  break;
	}
     
     }

     anterior = distanciaentrepontos;
 };

 japopulado=1;

}


var data = [
  {'title': 'marker1', 'position': {lat: xxx, lng: xxx},'id':0},
  {'title': 'marker2', 'position': {lat: xxx, lng: xxx},'id':1},
   ...
  {'title': 'markerN', 'position': {lat: xxx, lng: xxx}'id':100}
];


//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
var japopulado = 0;
var proximos = [];


var data = [
      ['Bondi Beach', -33.890542, 151.274856, 4],
      ['Coogee Beach', -33.923036, 151.259052, 5],
      ['Cronulla Beach', -34.028249, 151.157507, 3],
      ['Manly Beach', -33.80010128657071, 151.28747820854187, 2],
      ['Maroubra Beach', -33.950198, 151.259302, 1]
];

function rola(){
alert(data[1][0]);
  alert(distancia(5,5,6,4));
}




function pontosproximos(arraydepontos){

  var anterior = 200000;
  var maximodepontos = 5;

 for (var i = 0; i < arraydepontos.length; i++) {

     if (japopulado == 0){
	
	if (maximodepontos <= 5){

           var distanciaentrepontos = distancia(arraydepontos[i][1],arraydepontos[i][2],atuallat,atuallng);

	   if (distanciaentrepontos<anterior){
               proximos.push(arraydepontos[i][1]+","+arraydepontos[i][2]+","+distanciaentrepontos);
	       maximodepontos +=1;
	   }

	}else{
	   break;
	}
      anterior = distanciaentrepontos;
     }else{
	var distanciaentrepontos2 = distancia(arraydepontos[i][1],arraydepontos[i][2],atuallat,atuallng);

	if (maximodepontos < 5){

	  for (var i = 0; i < proximos.length; i++) {

	      if (proximos < distanciaentrepontos2){
		 proximos[i] = (arraydepontos[i][1]+","+arraydepontos[i][1]+","+distanciaentrepontos2);
		 maximodepontos +=1;
	      }
	      
	  }

	}else{
 	  break;
	}
     anterior = distanciaentrepontos2;
     }
 };

 japopulado=1;

}

function distancia(l,a,c,f){
  //essa fun��o e pra calcular a distancia dos pontos
  return Math.floor((Math.random() * 1000) + 1);
}

:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

var japopulado = 0;
var proximos = [];
var atuallat = -33.890542;
var atuallng = 151.274856;

var data = [
      ['Bondi Beach', -33.890542, 151.274856, 4],
      ['Coogee Beach', -33.923036, 151.259052, 5],
      ['Cronulla Beach', -34.028249, 151.157507, 3],
      ['Manly Beach', -33.80010128657071, 151.28747820854187, 2],
      ['Manly Beach', -333.80010128657071, 1515.28747820854187, 2],
      ['Manly Beach', -336.800130128657071, 1581.28747820854187, 2],
      ['Manly Beach', -1133.80010128657071, 11151.28747820854187, 2],
      ['Manly Beach', -3443.80010128657071, 16551.28747820854187, 2],
      ['Manly Beach', -335566.80010128657071, 666151.28747820854187, 2],
      ['Maroubra Beach', -33.950198, 151.259302, 1]
];

 //teste
function rola(){
 //chama a fun��o passando os parametros tudo
 pontosproximos(data);
  
  //quantos pontos proximos tem
  alert(proximos.length);
  
  //mostra todos pontos proxims
   for (var i = 0; i < proximos.length; i++) {
    alert(proximos[i]);
   }
}

//essa e foda
function pontosproximos(arraydepontos){
  //um valor inicial de referencia
  var anterior = distancia(arraydepontos[0][1],arraydepontos[0][2],atuallat,atuallng);
  //um tamanho maximo de pontos 
  var maximodepontos = 5;
  
  //zera o array de pontosproximos pra evitar de travar ou lixo no array
  if (japopulado == 0){
     proximos = [];
  }

 for (var i = 0; i < arraydepontos.length-1; i++) {

     if (japopulado == 0){
	    
	if (maximodepontos >= 5){
            //pega os valores do array que foi passado como parametro pra fun��o, mas pq o +1 ?, vc e burro ?
            //pq a posi��o zero eu guei no inicio ent�o prexiso sempre da proxima
           var distanciaentrepontos = distancia(arraydepontos[i+1][1],arraydepontos[i+1][2],atuallat,atuallng);
    
//comparar qual a ddistancia mais proxima
	   if (distanciaentrepontos<anterior){
               proximos.push(arraydepontos[i][1]+","+arraydepontos[i][2]+","+distanciaentrepontos);
	       maximodepontos +=1;
	   }

	}else{
    //se bateu o limite ele sai do for
	   break;
	}
       //o anterior pra ele ter como parametro pro proximo
      anterior = distanciaentrepontos;
     }else{
	var distanciaentrepontos2 = distancia(arraydepontos[i][1],arraydepontos[i][2],atuallat,atuallng);

	if (maximodepontos >= 5){

	  for (var i = 0; i < proximos.length; i++) {

	      if (proximos < distanciaentrepontos2){
		 proximos[i] = (arraydepontos[i][1]+","+arraydepontos[i][1]+","+distanciaentrepontos2);
		 maximodepontos +=1;
	      }
	      
	  }

	}else{
 	  break;
	}
     anterior = distanciaentrepontos2;
     }
 };

 japopulado=1;

}

function distancia(l,a,c,f){
  //essa fun��o e pra calcular a distancia dos pontos
  return Math.floor((Math.random() * 1000) + 1);
}


:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::;

//localiza��o do infeliz do usu�rio
var atuallat = -33.890542;
var atuallng = 151.274856;

//aqui vai ficar os pontos proximos
var distnciadosponto = [];

//os pontos 
var data = [
      ['Bondi Beach', -33.890542, 151.274856, 4],
      ['Coogee Beach', -33.923036, 151.259052, 5],
      ['Cronulla Beach', -34.028249, 151.157507, 3],
      ['Manly Beach', -33.80010128657071, 151.28747820854187, 2],
      ['Manly Beach', -333.80010128657071, 1515.28747820854187, 2],
      ['Manly Beach', -336.800130128657071, 1581.28747820854187, 2],
      ['Manly Beach', -1133.80010128657071, 11151.28747820854187, 2],
      ['Manly Beach', -3443.80010128657071, 16551.28747820854187, 2],
      ['Manly Beach', -335566.80010128657071, 666151.28747820854187, 2],
      ['Maroubra Beach', -33.950198, 151.259302, 1]
];

 //teste
function rola(){
 //chama a fun��o passando os pontos para gerar um array com a distancia em km dos pontos
 pontosproximos(data);
 //printa os pontos mais proximos
 verificaspontosproximos(distnciadosponto);
  
}

//essa e foda
function pontosproximos(arraydepontos){
  //pra zerar o array de saida
  
   distnciadosponto = [];
   for (var i = 0; i < arraydepontos.length; i++) {
        //pega a distancia em km
        var distanciaemkm = distancia(arraydepontos[i][1],arraydepontos[i][2],atuallat,atuallng);
        //adiciona no array de distancia a distancia em km de cada ponto e as coordenadas
        distnciadosponto[i] = (distanciaemkm+","+arraydepontos[i][1]+","+arraydepontos[i][2]);
    }
}

//depois do array de distnciadosponto ser preenchido essa fun��o pega os menores valores e printa
function verificaspontosproximos(arraydekm){
      //pra n gerar lixo na variavel
      var novoarraydepontos;
      //ordena por tamanho
      novoarraydepontos  = arraydekm.sort();
        
        for (var i = 0; i < 5; i++) {
          alert(novoarraydepontos[i]);
        }
}

function distancia(l,a,c,f){
  //essa fun��o e pra calcular a distancia dos pontos
  return Math.floor((Math.random() * 1000) + 1);
}


