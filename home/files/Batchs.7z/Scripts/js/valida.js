function validateForm(){

if(document.Pedidoform.usrname.value=="" || document.Pedidoform.tx_nome.value.length < 8){
	alert( "Preencha o campo NOME corretamente!" );
	document.Pedidoform.usrname.focus();
	return false;
}

if(document.Pedidoform.endereco.value=="" || document.Pedidoform.endereco.value.length < 8){
	alert( "Preencha o campo endereco corretamente!" );
	document.Pedidoform.endereco.focus();
	return false;
}

if(document.Pedidoform.tel.value=="" || document.Pedidoform.tel.value.length < 8){
	alert( "Preencha o campo telefone corretamente!" );
	document.Pedidoform.tel.focus();
	return false;
}


if(document.Pedidoform.quantiti.value.length < 0){
	alert( "Preencha o campo Quantidade corretamente!" );
	document.Pedidoform.quantiti.focus();
	return false;
}


if (document.Pedidoform.sabor[0].checked == false && document.Pedidoform.sabor[1].checked == false && document.Pedidoform.sabor[2].checked == false) {
  	alert("Por favor, selecione o sabo!");
        return false;

}

if(document.Pedidoform.sel.value==""){
	alert("Por favor, selecione o tamanho!");
	return false;
}

}