﻿var erro =  0;
String.prototype.replaceAll = function(antes, depois){
var palavra = this;
var posicao = palavra.indexOf(antes);

while (posicao > -1){
palavra = palavra.replace(antes, depois);
posicao = palavra.indexOf(antes);
}

return (palavra);
}

function corrigir(txt){ 
inimai();
if (erro==0){
if(document.all.txt.value.toLowerCase){
ler = {
'  ': {'por': ' '},
'Gerencia': {'por': 'Gerência'},
'gerencia': {'por': 'gerência'},
'Gerêncial': {'por': 'Gerencial'},
'gerêncial': {'por': 'gerencial'},
'Numero': {'por': 'Número'},
'numero': {'por': 'número'},
'usuario': {'por': 'Usuário'},
'usuaria': {'por': 'Usuária'},
'Usuario': {'por': 'Usuário'},
'Usuaria': {'por': 'Usuária'},
'Atraves': {'por': 'Através'},
'atraves': {'por': 'através'},
'Opição': {'por': 'Opção'},
'opição': {'por': 'opção'},
'opiçao': {'por': 'opção'},
'Opiçao': {'por': 'Opção'},
'opçao': {'por': 'opção'},
'Opçao': {'por': 'Opção'}, 
'Transferencia': {'por': 'Transferência'},
'transferencia': {'por': 'transferência'}, 
'necessario': {'por': 'necessário'},
'necesario': {'por': 'necessário'},
'nesessario': {'por': 'necessário'},
'Necessario': {'por': 'Necessário'},
'Necesario': {'por': 'Necessário'},
'Nesessario': {'por': 'Necessário'},
'nescessario': {'por': 'necessário'},
'nescesario': {'por': 'necessário'},
'nesessario': {'por': 'necessário'},
'Nescessario': {'por': 'Necessário'},
'Nescesario': {'por': 'Necessário'},
'Nesessario': {'por': 'Necessário'},
'nessecario': {'por': 'necessário'},
'Nessecario': {'por': 'Necessário'},
'esta': {'por': 'está'},
'estáção': {'por': 'estação'},
'ja': {'por': 'já'},
'Desejá': {'por': 'Deseja'},
'desejá': {'por': 'deseja'},
'uteis': {'por': 'úteis'},
'Codigo': {'por': 'Código'},
'codigo': {'por': 'código'},
'transferencia': {'por': 'transferência'},
'transferencia': {'por': 'transferência'},
'tranferencia': {'por': 'transferência'},
'tranferência': {'por': 'transferência'},
'Transferencia': {'por': 'Transferência'},
'Transferencia': {'por': 'Transferência'},
'Tranferencia': {'por': 'Transferência'},
'Tranferência': {'por': 'Transferência'},
'Urgencia': {'por': 'Urgência'},
'urgencia': {'por': 'urgência'},
'Eletronico': {'por': 'Eletrônico'},
'eletronico': {'por': 'eletrônico'},
'sera': {'por': 'será'},
'Sera': {'por': 'Será'},
'historico': {'por': 'histórico'},
'Historico': {'por': 'Histórico'},
'juridica': {'por': 'jurídica'},
'Juridica': {'por': 'Jurídica'},
'juridico': {'por': 'jurídico'},
'Juridico': {'por': 'Jurídico'},
'fisica': {'por': 'física'},
'Fisica': {'por': 'Física'},
'formulario': {'por': 'formulários'},
'Formulario': {'por': 'Formulários'}, 
'acessorios': {'por': 'acessórios'},
'Acessorios': {'por': 'Acessórios'}, 
'Portatil': {'por': 'portátil'},
'portatil': {'por': 'portátil'},
'laboratorio': {'por': 'laboratório'},
'Laboratorio': {'por': 'Laboratório'},
'Subimenu': {'por': 'Submenu'},
'subimenu': {'por': 'submenu'},
'Possivel': {'por': 'Possível'},
'possivel': {'por': 'possível'},
'secretaria': {'por': 'secretária'},
'Secretaria': {'por': 'Secretária'},
'tecnico': {'por': 'técnico'},
'Tecnico': {'por': 'Técnico'},
'Sitel': {'por': 'SITEL'},
'sitel': {'por': 'SITEL'},
'telefonica': {'por': 'telefônica'},
'Telefonica': {'por': 'Telefônica'},
'Referencia': {'por': 'Referência'},
'referencia': {'por': 'referência'},
'emergencia': {'por': 'emergência'},
'Emergencia': {'por': 'Emergência'},
'emergêncial': {'por': 'emergencial'},
'Emergêncial': {'por': 'Emergencial'},
'auxilio': {'por': 'auxílio'},
'Auxilio': {'por': 'Auxílio'},
'area': {'por': 'área'},
'Area': {'por': 'Área'},
'Ip': {'por': 'IP'},
'Movel': {'por': 'Móvel'},
'movel': {'por': 'móvel'},
'video': {'por': 'vídeo'},
'Video': {'por': 'Vídeo'},
'simbolo': {'por': 'símbolo'},
'Simbolo': {'por': 'Símbolo'},  
'simbulo': {'por': 'símbolo'},
'Simbulo': {'por': 'Símbolo'},  
'responsavel': {'por': 'responsável'},  
'Responsavel': {'por': 'Responsável'},  
'radio': {'por': 'rádio'},  
'Radio': {'por': 'Rádio'},   
'Pagina': {'por': 'Página'},  
'pagina': {'por': 'página'},   
'proseguir': {'por': 'prosseguir'}, 
'Proseguir': {'por': 'Prosseguir'},   
'Geplat': {'por': 'GEPLAT'},
'Geplate': {'por': 'GEPLAT'},
'GEPLATE': {'por': 'GEPLAT'},  
'Stic': {'por': 'STIC'},
'stic': {'por': 'STIC'},  
'apos': {'por': 'após'}
 };
}       
var resultado = document.all.txt.value;
  
for (var i in ler){
resultado = resultado.replaceAll(i,ler[i].por);
}
  
document.all.txt.value=resultado;
}else{
  alert('Erro não e possível iniciar o corretor');
}  
}

function verificaepes(){
  if ('spellcheck' in document.createElement('textarea')) {
    'nice'
  } else {
    alert('Erro não e possível iniciar o corretor');
  }
}

function inimai(){
 var campotexto = document.getElementById ("txt");
  var texto = document.getElementById ("txt").value;
   var tamanho = document.getElementById ("txt").value.length;
     
     if (tamanho==1){
        var res = texto.substring(0,1).replace("a", "A").replace("b", "B").replace("c", "C").replace("d", "D").replace("e", "E").replace("f", "F").replace("g", "G").replace("g", "G").replace("h", "H").replace("i", "I").replace("j", "J").replace("k", "K").replace("l", "L").replace("m", "M").replace("n", "N").replace("o", "O").replace("p", "P").replace("q", "Q").replace("r", "R").replace("s", "S").replace("t", "T").replace("u", "U").replace("v", "V").replace("w", "W").replace("x", "X").replace("y", "Y").replace("z", "Z") ;
     	campotexto.value = res;

      }else{
           if(tem_minusculas(texto.replace(" ", "").substring(0,1))){
    
            var res2 = texto.replace("a", "A").replace("b", "B").replace("c", "C").replace("d", "D").replace("e", "E").replace("f", "F").replace("g", "G").replace("g", "G").replace("h", "H").replace("i", "I").replace("j", "J").replace("k", "K").replace("l", "L").replace("m", "M").replace("n", "N").replace("o", "O").replace("p", "P").replace("q", "Q").replace("r", "R").replace("s", "S").replace("t", "T").replace("u", "U").replace("v", "V").replace("w", "W").replace("x", "X").replace("y", "Y").replace("z", "Z") ;
     	     campotexto.value = res2+texto.substring(1,1000);
          }

      }
  
    
}

var letras="abcdefghyjklmnopqrstuvwxyz";

function tem_minusculas(texto){
   for(i=0; i<texto.length; i++){
      if (letras.indexOf(texto.charAt(i),0)!=-1){
         return 1;
      }
   }
   return 0;
} 
