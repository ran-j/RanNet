﻿var enter =  0;
var erro =  0;

var errado =["Gerencia","gerencia","Usuario","usuario","gerêncial","Gerêncial","numero","Numero","atraves","Atraves","opição","Opição","opiçao","Opiçao","opçao","Opçao","Transferencia","transferencia","Necessario","necessario","necesario","nesessario","Necessario","Necesario","Nesessario","nescessario","nescesario","nesessario","Nescessario","Nescesario","Nesessario","nessecario","Nessecario","esta","testár","Testár","testándo","Testándo","testára","Testára","estáção","uteis","Codigo","codigo","transferencia","transferencia","tranferencia","tranferência","Transferencia","Transferencia","Tranferencia","Tranferência","Urgencia","urgencia","Eletronico","eletronico","sera","Sera","historico","Historico","juridica","Juridica","juridico","Juridico","fisica","Fisica","formulario","Formulario","acessorios","Acessorios","Portatil","portatil","laboratorio","Laboratorio","Subimenu","subimenu","Possivel","possivel","secretaria","Secretaria","tecnico","Tecnico","Sitel","sitel","telefonica","Telefonica","Referencia","referencia","emergencia","Emergencia","emergêncial","Emergêncial","auxilio","Auxilio","area","Area","Ip","Movel","movel","video","Video","simbolo","Simbolo","simbulo","Simbulo","responsavel","Responsavel","radio","Radio","Pagina","pagina","proseguir","Proseguir","Geplat","Geplate","GEPLATE","Stic","stic","apos","Usuaria","usuaria","estára","Estára","critica","Critica"];                                                    


var certo=["Gerência","gerência","Usuário","Usuário","gerencial","Gerencial","número","Número","através","Através","opção","Opção","opção","Opção","opção","Opção","Transferência","transferência","Necessário","necessário","necessário","necessário","Necessário","Necessário","Necessário","necessário","necessário","necessário","Necessário","Necessário","Necessário","necessário","Necessário","está","testar","Testar","testando","Testando","testará","Testará","estação","úteis","Código","código","transferência","transferência","transferência","transferência","Transferência","Transferência","Transferência","Transferência","Urgência","urgência","Eletrônico","eletrônico","será","Será","histórico","Histórico","jurídica","Jurídica","jurídico","Jurídico","física","Física","formulários","Formulários","acessórios","Acessórios","Portátil","portátil","laboratório","Laboratório","Submenu","submenu","Possível","possível","secretária","Secretária","técnico","Técnico","SITEL","SITEL","telefônica","Telefônica","Referência","referência","emergência","Emergência","emergencial","Emergencial","auxílio","Auxílio","área","Área","IP","Móvel","móvel","vídeo","Vídeo","símbolo","Símbolo","símbolo","Símbolo","responsável","Responsável","rádio","Rádio","Página","página","prosseguir","Prosseguir","GEPLAT","GEPLAT","GEPLAT","STIC","STIC","após","Usuária","usuária","estará","Estará","crítica","Crítica"];                                           

function corrigir(txt){ 
if (erro==0){
  if(enter==0){
   ativaspell();
   setTimeout(verificavazio(1), 3000);
  }
  var resultado = document.all.txt.value;
   for (var i in errado){
       resultado = resultado.replace(errado[i],certo[i]);
    }
    document.all.txt.value=resultado;
}else{
  alert('Erro não e possível iniciar o corretor');
}  
}

function verifitecla(e,txt){ 
if (e.keyCode == 13) {
      if(erro==0){
        enter=1;
        corrigir(txt);
        ativaspell();
        setTimeout(verificavazio(1), 3000);
      }else{
        alert('Erro não e possível iniciar o corretor');
      }
    }
}

function verificaepes(){
  if ('spellcheck' in document.createElement('textarea')) {
   alert("Digite a frase a ser corrigida e aperte enter ou clike no botão verificar");
  } else {
    alert('Erro não e possível iniciar o corretor');
  }
}

function desativaspell(){
    var area = document.getElementById ("txt");
    area.spellcheck = false;
}
function ativaspell(){
    var area = document.getElementById ("txt");
    area.spellcheck = true;
}

function verificavazio(op){
  inimai()
  var tamaho = document.getElementById ("txt").value;
  if(tamaho.length <= 0){
     enter=0;
     desativaspell();
  }else{
    if (op==1){
      setTimeout(verificavazio(1), 2000);
    }
  }
}

function inimai(){
 var campotexto = document.getElementById ("txt");
  var texto = document.getElementById ("txt").value;
  
     var res = texto.replace("a", "A").replace("b", "B").replace("c", "C").replace("d", "D").replace("e", "E").replace("f", "F").replace("g", "G").replace("g", "G").replace("h", "H").replace("i", "I").replace("j", "J").replace("k", "K").replace("l", "L").replace("m", "M").replace("n", "N").replace("o", "O").replace("p", "P").replace("q", "Q").replace("r", "R").replace("s", "S").replace("t", "T").replace("u", "U").replace("v", "V").replace("w", "W").replace("x", "X").replace("y", "Y").replace("z", "Z") ;
     campotexto.value = res.replace(" ", "").substring(0,1)+texto.substring(1,1000);
}